function [B,x0] = Buckets_CNG(data_na,radd)
%    桶,B是整个属性集合，A是属性子集,Bn为桶的数量

x0=min(data_na,[],1);
max = 0;
for i = 1:size(data_na,1)
        a = ceil(norm(data_na(i,:)-x0,2)/radd);
%     a = ceil(norm(data_na(i,:)-x0,"inf")/radd);
    if a>max
        max = a;   %预设桶的最大数量
    end
end
if max > 0
    B = cell(1,max+1);
else
    B=cell(1,1);
    B{1}=(1:size(data_na,1));
    return
end
for i = 1:size(data_na,1)
    if data_na(i,:)==x0
        B{1}(end+1) = i;   %如果有个对象的属性向量等于x0的属性向量，就都放入桶1
    else
                k = ceil(norm(data_na(i,:)-x0,2)/radd)+1;
        B{k}(end+1) = i;         %入桶
    end
end

end




