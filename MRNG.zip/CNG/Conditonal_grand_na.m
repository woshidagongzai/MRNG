function [CNG] = Conditonal_grand_na(NA,radd,D_class,D_classnum)
%CONDITONAL_GRAND_NA
%   此处显示详细说明
CNG=0;
n=size(NA,1);
MM=EURelation(NA,radd);

for i=1:n
    for j=1:D_classnum
        tt=(sum(min(MM(i,:),D_class(j,:)),"all"));
        tt_1=(tt*(sum(MM(i,:),"all")-tt))/n^2;
        CNG=CNG+tt_1;
    end
end

end
