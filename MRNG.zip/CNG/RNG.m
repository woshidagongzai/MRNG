function [RED] = RNG(U,radd)
%U is structure which includes
% U.SA symbolic attributes, U.NA  numerical attributes, U.D  decision attribute.
ATT=[U.SA,nomalizeMm1(U.NA)];
lab=1:size(ATT,2);
reduc_NA=[];
reduc_SA=[];
reduclab=[];
n=size(ATT,1);
m=size(ATT,2);
if m>1000
    sita=0.01;
else
    sita=0.001;
end
NAMM=eye(n);
SAMM=eye(n);
SA_SIZE=size(U.SA,2);
tab1=100000000;
MD=ERelation(U.D);
D_class=unique(MD,"rows");%new
D_classnum=size(D_class,1);%new
start=1;
while  start
    RCNG=zeros(1,size(lab,2));
    for j=1:size(lab,2)
        i=lab(j);
        if i>SA_SIZE
            reduc_na=[reduc_NA,ATT(:,i)];
            if ~isempty(reduc_SA)
                CNG=Conditonal_grand_na_mix(reduc_na,radd,D_class,D_classnum,SAMM);
            else
                CNG=Conditonal_grand_na(reduc_na,radd,D_class,D_classnum);
            end
        else
            reduc_sa=[reduc_SA,ATT(:,i)];
            if ~isempty(reduc_NA)
                CNG=Conditional_grand_sa_mix(reduc_sa,NAMM,D_class,D_classnum);
            else
                CNG=Conditional_grand_sa(reduc_sa,D_class,D_classnum);
            end
        end
        RCNG(1,j)=CNG;
    end
    [tab,lab_1]=min(RCNG);
    if tab1-tab>sita
        tab1=tab;
        reduclab=[reduclab,lab(lab_1)];
        if lab(lab_1)>SA_SIZE
            reduc_NA=[reduc_NA,ATT(:,lab(lab_1))];
            NAMM=EURelation(reduc_NA,radd);
        else
            reduc_SA=[reduc_SA,ATT(:,lab(lab_1))];
            SAMM=ERelation(reduc_SA);
        end
        lab(lab_1)=[];
    else
        break
    end
end
RED=reduclab;
end

