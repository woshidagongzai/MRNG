function M = EURelation(NA,radd)
%EURELATION 欧式距离邻域关系矩阵
%   此处显示详细说明
n=size(NA,1);
M=eye(n);
for i=1:n
    for j=i:n
        if norm(NA(i,:)-NA(j,:),2)<=radd
            M(i,j)=1;M(j,i)=1;
        else
            continue
        end
    end
end
end

