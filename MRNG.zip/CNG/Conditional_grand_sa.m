function [CNG] = Conditional_grand_sa(SA,D_class,D_classnum)
%CONDITIONAL_GRAND_SA 
%   
n=size(SA,1);

CNG=0;
MM=ERelation(SA);

%%
for i=1:n
    for j=1:D_classnum
        tt=(sum(min(MM(i,:),D_class(j,:)),"all"));
        tt_1=(tt*(sum(MM(i,:),"all")-tt))/n^2;
        CNG=CNG+tt_1;
    end
end
end


