function [CNG] = Conditonal_grand_na_mix(NA,radd,D_class,D_classnum,SAMM)
%CONDITONAL_GRAND_MIX 混合数据的条件邻域粒度
%   NA为数值属性，ZONE为符号型数据形成的各个域,MD为决策属性矩阵
n=size(NA,1);
NAMM=EURelation(NA,radd);
MM=min(SAMM,NAMM);

CNG=0;


for i=1:n
    for j=1:D_classnum
        tt=(sum(min(MM(i,:),D_class(j,:)),"all"));
        tt_1=(tt*(sum(MM(i,:),"all")-tt))/n^2;
        CNG=CNG+tt_1;
    end
end
end

