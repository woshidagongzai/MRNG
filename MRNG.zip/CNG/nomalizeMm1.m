function [liA1] = nomalizeMm1(A)
%LIM1 将属性归一化
%   返回的是0-1之间的矩阵
ma=min(A,[],1);
Ma=max(A,[],1);
da=Ma-ma;
for i=1:size(A,2)
   A(:,i)= (A(:,i)-ma(1,i))./da(1,i);
end
liA1=A;
end


