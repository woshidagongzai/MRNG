function [ZONE] = fresh_zone_CNG(SA)
%FRESH_ZONE 此处显示有关此函数的摘要
%   此处显示详细说明
classes=unique(SA,'rows');
m=size(classes,1);
n=size(SA,1);
ZONE = cell(1,m);
for i=1:n
    for j=1:m
        if SA(i,:)==classes(j,:)
            ZONE{j}(end+1)=i;
            break
        else
            continue
        end
    end
end
end

