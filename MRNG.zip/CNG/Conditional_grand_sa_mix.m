function [CNG] = Conditional_grand_sa_mix(SA,NAMM,D_class,D_classnum)
%CONDITIONAL_GRAND_SA_MIX 此处显示有关此函数的摘要
%   此处显示详细说明

n=size(SA,1);
CNG=0;
SAMM=ERelation(SA);
MM=min(SAMM,NAMM);
%%
for i=1:n
    for j=1:D_classnum
        tt=(sum(min(MM(i,:),D_class(j,:)),"all"));
        tt_1=(tt*(sum(MM(i,:),"all")-tt))/n^2;
        CNG=CNG+tt_1;
    end
end

end
